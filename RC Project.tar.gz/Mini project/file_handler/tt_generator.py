    a = not a
    c = a ^ c
    c = (a and b) ^ c
