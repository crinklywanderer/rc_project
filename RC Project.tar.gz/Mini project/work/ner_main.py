from nltk.book import *

# text1
# text2

text1.concordance("monstrous")

text4.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])
