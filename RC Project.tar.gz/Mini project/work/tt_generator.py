e=(a and b and c and d)^e
