import PyQt4
import sys
from PyQt4.QtCore import *
x = PyQt4.QtCore.QString('aayush')
y = PyQt4.QtCore.QDate()
print x
print y
xx = 'my name is aayush'
xy  = 'sonkar'
sys.stdout.write(xx + '\n' + xy)

al = [1,32,3]
print '\n', al
al[1] = 69
print '\n' , al